create definer = root@localhost view client_project_due_date as
select 'client_id' AS `client_id`, 'customer' AS `customer`, 'project_name' AS `project_name`, 'due_date' AS `due_date`
from (`harmonic_environment`.`harmonic_client`
         join `harmonic_environment`.`project` on ((0 <> 'client_id')));

