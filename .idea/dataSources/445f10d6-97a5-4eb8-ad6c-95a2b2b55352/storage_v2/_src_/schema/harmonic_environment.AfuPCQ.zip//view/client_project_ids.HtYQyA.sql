create definer = root@localhost view client_project_ids as
select 'client_id' AS `client_id`, 'project_id' AS `project_id`
from (`harmonic_environment`.`harmonic_client`
         join `harmonic_environment`.`project` on ((0 <> 'client_id')));

