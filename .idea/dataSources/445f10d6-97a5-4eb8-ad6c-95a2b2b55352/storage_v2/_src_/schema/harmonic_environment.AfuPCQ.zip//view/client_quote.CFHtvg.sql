create definer = root@localhost view client_quote as
select 'client_id' AS `client_id`, 'customer' AS `customer`, 'project_name' AS `project_name`, 'quote' AS `quote`
from ((`harmonic_environment`.`harmonic_client` join `harmonic_environment`.`project` on ((0 <> 'client_id')))
         join `harmonic_environment`.`quote` on ((0 <> 'project_id')));

